
//const user = process.env.aevi_user
//const password = process.env.aevi_password
//const web_page = process.env.web_page


exports.config = {
  tests: './e2etests/*_test.js',
  output: './output',
  helpers: {
    WebDriver: {
      url: 'http://localhost',
      browser: 'chrome',
      windowSize: '1920x1080'
    }
  },
  plugins: {
    wdio: {
      enabled: true,
      services: ['selenium-standalone']
    },
    autoLogin: {
      enabled: true,
      saveToFile: true,
      inject: 'login',
      users: {
        admin: {
          // login function is defined in `steps_file.js`
          login: (I) => I.login(),
          // if we see `Signed in successfully.` on page, we assume we are logged in
          check: (I) => {
            //   pause();
             I.amOnPage(process.env.test_site);
            //  console.log('check');
             I.see('Signed in successfully.');
             }
           }
         }
       }
  },
  include: {
    I: './steps_file.js'
  },
  bootstrap: null,
  mocha: {},
  name: 'e2e_codecept_selenium'
}
