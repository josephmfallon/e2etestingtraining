Feature('navigateToAEVIDev');

//Scenario('navigate to the AEVI developer homepage', (I) => {
    //I.amOnPage('https://developer.aevi.com/');
    //I.see('Let’s create a better merchant experience');
    // broken test on purpose - fix it!
//});

//Scenario('navigate to the AEVI developer homepage', (I) => {
    //I.amOnPage('https://developer.aevi.com/');
    //I.click('Sign up');
   // I.see('Terms of Use for AEVI Websites');
//});

//Scenario('Navitage to example.com', (I) => {
//    I.amOnPage(process.env.web_page);
//    I.see('Example Domain');
//
//});

//Scenario("Login to developer test portal" , (I) => {
//      I.amOnPage(process.env.test_site);
//      I.fillField('Email', process.env.aevi_user);
//      I.fillField('Password', process.env.aevi_password);
//      I.click('Log in');
//      I.see('Signed in successfully.')
//
//});

Before(login => {
   login('admin'); // login using user session
});

Scenario("test autologin functionality" , (I) => {
    I.see('Signed in successfully.')

});
